// 调试发布脚本 - 在控制台手动运行此脚本来测试发布流程
// 使用方法：
// 1. 打开一个草稿视频页面 (https://sora.chatgpt.com/d/gen_xxx)
// 2. 打开控制台 (F12)
// 3. 复制粘贴此脚本并运行

(function() {
  console.log('\n' + '='.repeat(80));
  console.log('=== 调试发布脚本启动 ===');
  console.log('='.repeat(80));
  
  const logs = [];
  
  function log(msg) {
    const time = new Date().toLocaleTimeString();
    const logMsg = `[${time}] ${msg}`;
    logs.push(logMsg);
    console.log(logMsg);
  }
  
  log('步骤 1: 检查页面状态');
  log(`当前 URL: ${window.location.href}`);
  
  // 检查是否已经在编辑状态
  setTimeout(() => {
    log('\n步骤 2: 查找 textarea');
    let textarea = document.querySelector('textarea[placeholder="Add caption..."]');
    
    if (textarea) {
      log('✅ 找到 textarea，已经在编辑状态');
      log(`   当前内容: "${textarea.value}"`);
      proceedToPublish(textarea);
    } else {
      log('❌ 未找到 textarea，需要先点击编辑按钮');
      log('\n步骤 3: 查找编辑按钮');
      
      // 查找所有按钮
      const allButtons = document.querySelectorAll('button');
      log(`   页面共有 ${allButtons.length} 个按钮`);
      
      // 查找编辑按钮（铅笔图标）
      const editButton = Array.from(allButtons).find(btn => {
        const svg = btn.querySelector('svg');
        if (!svg) return false;
        
        const path = svg.querySelector('path');
        if (!path) return false;
        
        const d = path.getAttribute('d');
        return d && d.includes('M18.292 5.707');
      });
      
      if (!editButton) {
        log('❌ 未找到编辑按钮');
        log('   尝试查找所有包含 SVG 的按钮:');
        
        allButtons.forEach((btn, i) => {
          const svg = btn.querySelector('svg');
          if (svg) {
            const path = svg.querySelector('path');
            const d = path?.getAttribute('d');
            log(`   按钮 ${i}: ${d ? d.substring(0, 50) : 'no path'}`);
          }
        });
        
        return;
      }
      
      log('✅ 找到编辑按钮');
      log('   点击编辑按钮...');
      editButton.click();
      
      // 等待编辑界面出现
      setTimeout(() => {
        log('\n步骤 4: 再次查找 textarea');
        textarea = document.querySelector('textarea[placeholder="Add caption..."]');
        
        if (!textarea) {
          log('❌ 点击编辑按钮后仍未找到 textarea');
          return;
        }
        
        log('✅ 找到 textarea');
        log(`   当前内容: "${textarea.value}"`);
        proceedToPublish(textarea);
        
      }, 2000);
    }
  }, 2000);
  
  function proceedToPublish(textarea) {
    log('\n步骤 5: 清空提示词');
    
    const originalPrompt = textarea.value;
    log(`   原始提示词: "${originalPrompt}"`);
    
    // 聚焦并清空
    textarea.focus();
    textarea.value = '';
    
    // 触发事件
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
    
    log('✅ 提示词已清空');
    log(`   新内容: "${textarea.value}"`);
    
    // 查找保存按钮
    setTimeout(() => {
      log('\n步骤 6: 查找保存按钮（✓对勾图标）');
      
      const allButtons = document.querySelectorAll('button');
      log(`   页面共有 ${allButtons.length} 个按钮`);
      
      // 查找对勾按钮
      const saveButton = Array.from(allButtons).find(btn => {
        const svg = btn.querySelector('svg');
        if (!svg) return false;
        
        const viewBox = svg.getAttribute('viewBox');
        const path = svg.querySelector('path');
        const d = path?.getAttribute('d');
        
        return viewBox === '0 0 18 19' && d && d.includes('M13.548 4.755');
      });
      
      if (!saveButton) {
        log('❌ 未找到保存按钮');
        log('   尝试查找所有包含 SVG 的按钮:');
        
        allButtons.forEach((btn, i) => {
          const svg = btn.querySelector('svg');
          if (svg) {
            const viewBox = svg.getAttribute('viewBox');
            const path = svg.querySelector('path');
            const d = path?.getAttribute('d');
            log(`   按钮 ${i}: viewBox="${viewBox}", d="${d ? d.substring(0, 50) : 'no path'}"`);
          }
        });
        
        return;
      }
      
      log('✅ 找到保存按钮');
      
      const isDisabled = saveButton.getAttribute('data-disabled') === 'true';
      log(`   按钮状态: ${isDisabled ? '禁用' : '启用'}`);
      
      if (isDisabled) {
        log('   尝试启用按钮...');
        saveButton.setAttribute('data-disabled', 'false');
        saveButton.removeAttribute('disabled');
      }
      
      log('   点击保存按钮...');
      saveButton.click();
      
      // 查找 Post 按钮
      setTimeout(() => {
        log('\n步骤 7: 查找 Post 按钮');
        
        const allButtons = document.querySelectorAll('button');
        log(`   页面共有 ${allButtons.length} 个按钮`);
        
        const postButton = Array.from(allButtons).find(btn => 
          btn.textContent.trim() === 'Post' && 
          btn.classList.contains('bg-token-bg-inverse')
        );
        
        if (!postButton) {
          log('❌ 未找到 Post 按钮');
          log('   尝试查找所有可能的 Post 按钮:');
          
          allButtons.forEach((btn, i) => {
            const text = btn.textContent.trim();
            const classes = btn.className;
            if (text.includes('Post') || text.includes('发布')) {
              log(`   按钮 ${i}: "${text}", classes="${classes}"`);
            }
          });
          
          return;
        }
        
        log('✅ 找到 Post 按钮');
        
        const isPostDisabled = postButton.getAttribute('data-disabled') === 'true';
        log(`   按钮状态: ${isPostDisabled ? '禁用' : '启用'}`);
        
        if (isPostDisabled) {
          log('   尝试启用按钮...');
          postButton.setAttribute('data-disabled', 'false');
          postButton.removeAttribute('disabled');
        }
        
        log('   点击 Post 按钮...');
        postButton.click();
        
        setTimeout(() => {
          log('\n' + '='.repeat(80));
          log('✅ 发布流程完成！');
          log('='.repeat(80));
          
          // 输出所有日志
          console.log('\n完整日志:');
          logs.forEach(l => console.log(l));
          
        }, 2000);
        
      }, 2000);
      
    }, 1000);
  }
  
})();
