// 调试脚本 - 用于查找提示词的位置
// 在Sora视频页面的控制台运行这个脚本

console.log('=== 开始调试提示词提取 ===');

// 1. 查找所有文本内容
console.log('\n1. 查找所有可能的文本元素:');
const allElements = document.querySelectorAll('*');
const textElements = [];

allElements.forEach(el => {
  const text = (el.innerText || el.textContent || '').trim();
  
  // 只看长度在20-500之间的文本
  if (text.length > 20 && text.length < 500) {
    // 排除包含子元素文本的重复
    const hasTextChild = Array.from(el.children).some(child => {
      const childText = (child.innerText || child.textContent || '').trim();
      return childText.length > 10;
    });
    
    if (!hasTextChild || el.children.length === 0) {
      textElements.push({
        tag: el.tagName,
        class: el.className,
        id: el.id,
        text: text.substring(0, 100)
      });
    }
  }
});

console.log(`找到 ${textElements.length} 个文本元素`);
textElements.slice(0, 20).forEach((item, i) => {
  console.log(`[${i}] <${item.tag} class="${item.class}" id="${item.id}">`);
  console.log(`    ${item.text}`);
});

// 2. 查找 textarea
console.log('\n2. 查找 textarea:');
const textareas = document.querySelectorAll('textarea');
console.log(`找到 ${textareas.length} 个 textarea`);
textareas.forEach((ta, i) => {
  console.log(`[${i}] placeholder="${ta.placeholder}"`);
  console.log(`    value="${ta.value}"`);
});

// 3. 查找特定class的元素
console.log('\n3. 查找可能包含提示词的class:');
const possibleClasses = ['caption', 'text', 'description', 'prompt', 'title'];
possibleClasses.forEach(cls => {
  const elements = document.querySelectorAll(`[class*="${cls}"]`);
  if (elements.length > 0) {
    console.log(`\nclass包含"${cls}"的元素 (${elements.length}个):`);
    elements.forEach((el, i) => {
      if (i < 5) {
        const text = (el.innerText || el.textContent || '').trim();
        console.log(`  [${i}] ${el.tagName}.${el.className}`);
        console.log(`      ${text.substring(0, 100)}`);
      }
    });
  }
});

// 4. 查找段落标签
console.log('\n4. 查找所有 <p> 标签:');
const paragraphs = document.querySelectorAll('p');
console.log(`找到 ${paragraphs.length} 个 <p> 标签`);
paragraphs.forEach((p, i) => {
  if (i < 10) {
    const text = (p.innerText || p.textContent || '').trim();
    if (text.length > 10) {
      console.log(`[${i}] ${text.substring(0, 100)}`);
    }
  }
});

console.log('\n=== 调试完成 ===');
console.log('请查看上面的输出，找到包含真实提示词的元素');
