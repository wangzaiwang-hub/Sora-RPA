// Background script - 自动收集数据
console.log('=== Sora Background Service 启动 ===');

let videoData = {
  published: [],
  generating: [],
  unpublished: []
};

let accountInfo = null;
let isCollecting = false;
let collectionInterval = null;
let isPublishing = false;
let publishQueue = [];
let publishLogs = [];

// 监听来自 content script 的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('收到消息:', request.type);
  
  if (request.type === 'UPDATE_VIDEO_DATA') {
    videoData = request.data;
    console.log('收到视频数据更新:', videoData);
    sendResponse({ success: true });
  } else if (request.type === 'GET_VIDEO_DATA') {
    sendResponse(videoData);
  } else if (request.type === 'ACCOUNT_INFO') {
    accountInfo = request.account;
    console.log('收到账号信息:', accountInfo);
    sendResponse({ success: true });
  } else if (request.type === 'ADD_VIDEO') {
    // 添加单个视频（带去重）
    const video = request.video;
    
    // 检查是否已存在（根据 ID 去重）
    const checkDuplicate = (arr) => arr.some(v => v.id === video.id);
    
    if (video.status === 'published') {
      if (!checkDuplicate(videoData.published)) {
        videoData.published.push(video);
      }
    } else if (video.status === 'generating') {
      if (!checkDuplicate(videoData.generating)) {
        videoData.generating.push(video);
      }
    } else if (video.status === 'unpublished') {
      if (!checkDuplicate(videoData.unpublished)) {
        videoData.unpublished.push(video);
      }
    }
    sendResponse({ success: true });
  } else if (request.type === 'UPDATE_PROMPT') {
    // 更新视频的提示词
    const { videoId, prompt } = request;
    console.log(`更新视频 ${videoId} 的提示词: ${prompt.substring(0, 50)}`);
    
    // 在所有分类中查找并更新
    const updateInArray = (arr) => {
      const video = arr.find(v => v.id === videoId);
      if (video) {
        video.prompt = prompt;
        return true;
      }
      return false;
    };
    
    const updated = updateInArray(videoData.published) || 
                   updateInArray(videoData.generating) || 
                   updateInArray(videoData.unpublished);
    
    if (updated) {
      console.log(`✅ 提示词已更新`);
      // 保存到 storage
      chrome.storage.local.set({ 
        soraVideos: videoData,
        lastUpdate: new Date().toISOString()
      });
    }
    
    sendResponse({ success: true });
  } else if (request.type === 'COLLECTION_COMPLETE') {
    console.log(`${request.page} 页面收集完成，共 ${request.count} 个视频`);
    sendResponse({ success: true });
  } else if (request.type === 'START_AUTO_COLLECT') {
    console.log('收到启动自动收集命令');
    collectFromAllPages().then(() => {
      sendResponse({ success: true });
    });
    return true; // 保持消息通道打开
  } else if (request.type === 'STOP_AUTO_COLLECT') {
    stopAutoCollection();
    sendResponse({ success: true });
  } else if (request.type === 'START_AUTO_PUBLISH') {
    console.log('收到启动自动发布命令');
    startAutoPublish().then(() => {
      sendResponse({ success: true });
    });
    return true;
  } else if (request.type === 'STOP_AUTO_PUBLISH') {
    stopAutoPublish();
    sendResponse({ success: true });
  } else if (request.type === 'GET_PUBLISH_LOGS') {
    sendResponse({ logs: publishLogs });
  }
  return true;
});

// 自动收集数据
async function startAutoCollection() {
  if (isCollecting) {
    console.log('已经在收集中...');
    return;
  }
  
  console.log('🚀 启动自动收集');
  isCollecting = true;
  
  // 立即执行一次完整流程（收集+发布）
  await collectAndPublish();
  
  // 每 30 秒自动收集一次，并检查是否需要发布
  collectionInterval = setInterval(async () => {
    console.log('⏰ 定时自动收集');
    await collectAndPublish();
  }, 30 * 1000); // 30 秒
}

// 收集数据并自动发布未发布的视频
async function collectAndPublish() {
  console.log('📊 开始收集数据...');
  
  // 收集数据
  await collectFromAllPages();
  
  // 等待2秒
  await sleep(2000);
  
  // 检查是否有未发布的视频
  const result = await chrome.storage.local.get(['soraVideos']);
  const videos = result.soraVideos || { published: [], generating: [], unpublished: [] };
  const unpublishedVideos = videos.unpublished || [];
  
  if (unpublishedVideos.length > 0 && !isPublishing) {
    console.log(`📤 发现 ${unpublishedVideos.length} 个未发布视频，开始自动发布`);
    await startAutoPublishWithRefresh();
  } else if (unpublishedVideos.length === 0) {
    console.log('✅ 没有未发布的视频');
  } else {
    console.log('⏳ 正在发布中，跳过本次发布');
  }
}

function stopAutoCollection() {
  console.log('⏹️ 停止自动收集');
  isCollecting = false;
  if (collectionInterval) {
    clearInterval(collectionInterval);
    collectionInterval = null;
  }
}

// 从所有页面收集数据
async function collectFromAllPages() {
  console.log('📊 开始收集数据...');
  
  // 清空旧数据
  videoData = {
    published: [],
    generating: [],
    unpublished: []
  };
  
  try {
    // 1. 收集 profile 页面（已发布视频）
    console.log('1️⃣ 收集 profile 页面...');
    await collectFromPage('https://sora.chatgpt.com/profile', 'profile');
    
    // 等待 2 秒
    await sleep(2000);
    
    // 2. 收集 drafts 页面（未发布和生成中的视频）
    console.log('2️⃣ 收集 drafts 页面...');
    await collectFromPage('https://sora.chatgpt.com/drafts', 'drafts');
    
    console.log('✅ 收集完成！');
    console.log(`总计: ${videoData.published.length} 已发布, ${videoData.generating.length} 生成中, ${videoData.unpublished.length} 未发布`);
    
    // 等待一下，确保账号信息已经获取
    console.log('⏳ 等待账号信息...');
    await sleep(2000);
    
    // 暂时禁用自动收集提示词功能，避免频繁打开关闭标签页
    // 提示词会在用户手动访问视频页面时自动提取
    console.log('💡 提示：访问视频页面时会自动提取提示词');
    
    // 保存到 storage
    await chrome.storage.local.set({
      soraVideos: videoData,
      lastUpdate: new Date().toISOString()
    });
    
    console.log('💾 数据已保存到 storage');
    
    // 发送到后端
    await sendToBackend();
    
  } catch (error) {
    console.error('❌ 收集失败:', error);
  }
}

// 收集所有视频的提示词
async function collectPrompts() {
  // 合并所有视频
  const allVideos = [
    ...videoData.published,
    ...videoData.unpublished
  ];
  
  console.log(`📝 需要收集 ${allVideos.length} 个视频的提示词`);
  
  // 限制数量，避免打开太多标签页
  const maxVideos = Math.min(allVideos.length, 20);
  console.log(`   限制收集前 ${maxVideos} 个视频`);
  
  for (let i = 0; i < maxVideos; i++) {
    const video = allVideos[i];
    
    // 如果已经有提示词，跳过
    if (video.prompt && video.prompt.length > 10 && !video.prompt.toLowerCase().includes('placeholder')) {
      console.log(`⏭️ [${i + 1}/${maxVideos}] 跳过 ${video.id}（已有提示词）`);
      continue;
    }
    
    console.log(`📖 [${i + 1}/${maxVideos}] 打开 ${video.url} 获取提示词`);
    
    try {
      await collectPromptFromVideo(video);
    } catch (error) {
      console.error(`❌ 获取 ${video.id} 的提示词失败:`, error);
    }
    
    // 等待 2 秒再打开下一个
    if (i < maxVideos - 1) {
      await sleep(2000);
    }
  }
  
  console.log('✅ 提示词收集完成');
}

// 从单个视频页面收集提示词
async function collectPromptFromVideo(video) {
  return new Promise(async (resolve, reject) => {
    try {
      // 创建新标签页
      const tab = await chrome.tabs.create({
        url: video.url,
        active: false
      });
      
      // 等待页面加载
      await waitForTabLoad(tab.id);
      await sleep(3000); // 等待页面渲染
      
      // content script 会自动提取提示词并发送 UPDATE_PROMPT 消息
      // 我们只需要等待一下
      await sleep(2000);
      
      // 关闭标签页
      await chrome.tabs.remove(tab.id);
      
      resolve();
    } catch (error) {
      reject(error);
    }
  });
}

// 从指定页面收集数据
async function collectFromPage(url, pageType) {
  return new Promise(async (resolve, reject) => {
    try {
      console.log(`📖 打开页面: ${url}`);
      
      // 创建新标签页
      const tab = await chrome.tabs.create({
        url: url,
        active: false // 后台打开，不切换到该标签
      });
      
      console.log(`✅ 标签页已创建: ${tab.id}`);
      
      // 等待页面加载完成
      console.log('⏳ 等待页面加载...');
      await waitForTabLoad(tab.id);
      console.log('✅ 页面加载完成');
      
      // drafts 页面需要更长的等待时间
      const waitTime = pageType === 'drafts' ? 8000 : 5000;
      console.log(`⏳ 等待 content script 注入和页面渲染（${waitTime/1000}秒）...`);
      await sleep(waitTime);
      
      // 检查 content script 是否已注入
      console.log('🔍 检查 content script 状态...');
      let scriptReady = false;
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { type: 'GET_VIDEOS' });
        scriptReady = true;
        console.log('✅ Content script 已就绪');
      } catch (error) {
        console.warn('⚠️ Content script 未就绪，等待额外 3 秒...');
        await sleep(3000);
      }
      
      // 手动触发收集
      console.log('📤 发送收集命令到 content script...');
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'COLLECT_NOW' });
        console.log('✅ 收集命令已发送');
      } catch (error) {
        console.warn('⚠️ 发送收集命令失败:', error.message);
        console.warn('   可能原因: content script 未注入或页面未加载完成');
      }
      
      // drafts 页面需要更长的收集时间
      const collectTime = pageType === 'drafts' ? 25000 : 20000;
      console.log(`⏳ 等待数据收集（${collectTime/1000}秒）...`);
      await sleep(collectTime);
      
      // 再次检查收集到的数据
      console.log('🔍 检查收集结果...');
      try {
        const videos = await chrome.tabs.sendMessage(tab.id, { type: 'GET_VIDEOS' });
        const total = (videos.published?.length || 0) + (videos.generating?.length || 0) + (videos.unpublished?.length || 0);
        console.log(`📊 收集到 ${total} 个视频 (已发布: ${videos.published?.length || 0}, 生成中: ${videos.generating?.length || 0}, 未发布: ${videos.unpublished?.length || 0})`);
      } catch (error) {
        console.warn('⚠️ 无法获取收集结果');
      }
      
      // 关闭标签页
      console.log(`🗑️ 关闭标签页: ${tab.id}`);
      await chrome.tabs.remove(tab.id);
      
      console.log(`✅ ${pageType} 页面收集完成`);
      resolve();
      
    } catch (error) {
      console.error(`❌ 收集 ${pageType} 页面失败:`, error);
      reject(error);
    }
  });
}

// 等待标签页加载完成
function waitForTabLoad(tabId) {
  return new Promise((resolve) => {
    const listener = (updatedTabId, changeInfo) => {
      if (updatedTabId === tabId && changeInfo.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        console.log(`✅ 标签页 ${tabId} 加载完成`);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
    
    // 超时保护（15秒）
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      console.log(`⚠️ 标签页 ${tabId} 加载超时，继续执行`);
      resolve();
    }, 15000);
  });
}

// 发送数据到后端
async function sendToBackend() {
  try {
    const result = await chrome.storage.local.get(['backendUrl', 'soraAccountInfo']);
    const backendUrl = result.backendUrl || 'http://localhost:8000';
    const account = result.soraAccountInfo || accountInfo;
    
    const statsData = {
      totalVideos: videoData.published.length + videoData.generating.length + videoData.unpublished.length,
      publishedVideos: videoData.published.length,
      generatingVideos: videoData.generating.length,
      unpublishedVideos: videoData.unpublished.length,
      videos: videoData,
      account: account,
      lastUpdate: new Date().toISOString()
    };
    
    console.log('📤 发送数据到后端:', backendUrl);
    console.log('📦 数据内容:', statsData);
    
    const response = await fetch(`${backendUrl}/v1/videos/stats`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(statsData)
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('✅ 数据发送成功:', result);
    } else {
      console.warn('⚠️ 数据发送失败:', response.status, await response.text());
    }
  } catch (error) {
    console.error('❌ 发送数据失败:', error);
  }
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// 监听标签页更新，检测是否进入 explore 页面
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('sora.chatgpt.com/explore')) {
    console.log('🎯 检测到进入 explore 页面，启动自动化流程');
    startAutoWorkflow();
  }
});

// 监听标签页切换，检测是否离开 explore 页面
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const tab = await chrome.tabs.get(activeInfo.tabId);
  if (tab.url && !tab.url.includes('sora.chatgpt.com/explore')) {
    if (isCollecting) {
      console.log('🛑 离开 explore 页面，停止自动收集');
      stopAutoCollection();
    }
  }
});

// 监听标签页关闭
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  if (isCollecting) {
    console.log('🛑 标签页关闭，停止自动收集');
    stopAutoCollection();
  }
});

// 自动化工作流程：收集 → 发布 → 循环收集
async function startAutoWorkflow() {
  console.log('🚀 启动自动化工作流程');
  
  // 步骤1: 初始收集数据
  console.log('📊 步骤1: 收集初始数据');
  await collectFromAllPages();
  
  // 等待2秒
  await sleep(2000);
  
  // 步骤2: 检查是否有未发布的视频
  const result = await chrome.storage.local.get(['soraVideos']);
  const videos = result.soraVideos || { published: [], generating: [], unpublished: [] };
  const unpublishedVideos = videos.unpublished || [];
  
  if (unpublishedVideos.length > 0) {
    console.log(`📤 步骤2: 发现 ${unpublishedVideos.length} 个未发布视频，开始自动发布`);
    await startAutoPublishWithRefresh();
  } else {
    console.log('✅ 步骤2: 没有未发布的视频，跳过发布');
  }
  
  // 步骤3: 进入循环收集模式
  console.log('🔄 步骤3: 进入每30秒自动收集模式');
  startAutoCollection();
}

// 监听插件安装/更新
chrome.runtime.onInstalled.addListener((details) => {
  console.log('🔧 插件已安装/更新:', details.reason);
  console.log('💡 进入 https://sora.chatgpt.com/explore 页面将自动开始收集数据');
});

// 监听插件启动
chrome.runtime.onStartup.addListener(() => {
  console.log('🚀 浏览器启动');
  console.log('💡 进入 https://sora.chatgpt.com/explore 页面将自动开始收集数据');
});

console.log('=== Sora Background Service 就绪 ===');
console.log('💡 提示: 进入 https://sora.chatgpt.com/explore 页面将自动开始收集数据');


// ==================== 自动发布功能 ====================

function addPublishLog(message, type = 'info') {
  const log = {
    time: new Date().toLocaleTimeString(),
    message,
    type
  };
  publishLogs.push(log);
  console.log(`[${log.time}] ${message}`);
  
  // 只保留最近100条日志
  if (publishLogs.length > 100) {
    publishLogs.shift();
  }
  
  // 保存到 storage
  chrome.storage.local.set({ publishLogs });
}

async function startAutoPublish() {
  if (isPublishing) {
    addPublishLog('已经在发布中...', 'warning');
    return;
  }
  
  addPublishLog('🚀 启动自动发布', 'info');
  isPublishing = true;
  publishLogs = []; // 清空旧日志
  
  // 从 storage 获取未发布的视频
  const result = await chrome.storage.local.get(['soraVideos']);
  const videos = result.soraVideos || { published: [], generating: [], unpublished: [] };
  const unpublishedVideos = videos.unpublished || [];
  
  addPublishLog(`📦 从 storage 读取到 ${unpublishedVideos.length} 个未发布视频`, 'info');
  
  if (unpublishedVideos.length === 0) {
    addPublishLog('没有未发布的视频', 'warning');
    isPublishing = false;
    return;
  }
  
  addPublishLog(`📝 准备发布 ${unpublishedVideos.length} 个视频`, 'success');
  publishQueue = [...unpublishedVideos];
  
  // 逐个发布
  for (let i = 0; i < publishQueue.length; i++) {
    const video = publishQueue[i];
    
    if (!isPublishing) {
      addPublishLog('发布已停止', 'warning');
      break;
    }
    
    addPublishLog(`📤 [${i + 1}/${publishQueue.length}] 开始发布: ${video.id}`, 'info');
    
    try {
      await publishVideo(video);
      addPublishLog(`✅ [${i + 1}/${publishQueue.length}] 发布成功: ${video.id}`, 'success');
    } catch (error) {
      addPublishLog(`❌ [${i + 1}/${publishQueue.length}] 发布失败: ${video.id} - ${error.message}`, 'error');
    }
    
    // 等待 5 秒再发布下一个
    if (i < publishQueue.length - 1) {
      addPublishLog('⏳ 等待 5 秒...', 'info');
      await sleep(5000);
    }
  }
  
  addPublishLog('✅ 自动发布完成', 'success');
  isPublishing = false;
}

// 带数据刷新的自动发布（每发布一个视频后重新收集数据）
async function startAutoPublishWithRefresh() {
  if (isPublishing) {
    addPublishLog('已经在发布中...', 'warning');
    return;
  }
  
  addPublishLog('🚀 启动自动发布（带数据刷新）', 'info');
  isPublishing = true;
  publishLogs = []; // 清空旧日志
  
  // 从 storage 获取未发布的视频
  let result = await chrome.storage.local.get(['soraVideos']);
  let videos = result.soraVideos || { published: [], generating: [], unpublished: [] };
  let unpublishedVideos = videos.unpublished || [];
  
  addPublishLog(`📦 从 storage 读取到 ${unpublishedVideos.length} 个未发布视频`, 'info');
  
  if (unpublishedVideos.length === 0) {
    addPublishLog('没有未发布的视频', 'warning');
    isPublishing = false;
    return;
  }
  
  let totalCount = unpublishedVideos.length;
  let publishedCount = 0;
  
  // 循环发布，每次发布后重新获取未发布列表
  while (unpublishedVideos.length > 0 && isPublishing) {
    const video = unpublishedVideos[0]; // 总是发布第一个
    publishedCount++;
    
    addPublishLog(`📤 [${publishedCount}/${totalCount}] 开始发布: ${video.id}`, 'info');
    
    try {
      await publishVideoWithRefresh(video);
      addPublishLog(`✅ [${publishedCount}/${totalCount}] 发布成功: ${video.id}`, 'success');
      
      // 发布成功后，重新收集数据
      addPublishLog('🔄 重新收集数据...', 'info');
      await collectFromAllPages();
      addPublishLog('✅ 数据已更新', 'success');
      
      // 重新获取未发布列表
      result = await chrome.storage.local.get(['soraVideos']);
      videos = result.soraVideos || { published: [], generating: [], unpublished: [] };
      unpublishedVideos = videos.unpublished || [];
      
      addPublishLog(`📊 剩余未发布视频: ${unpublishedVideos.length}`, 'info');
      
    } catch (error) {
      addPublishLog(`❌ [${publishedCount}/${totalCount}] 发布失败: ${video.id} - ${error.message}`, 'error');
      
      // 发布失败也重新收集数据，然后继续下一个
      addPublishLog('🔄 重新收集数据...', 'info');
      await collectFromAllPages();
      
      // 重新获取未发布列表
      result = await chrome.storage.local.get(['soraVideos']);
      videos = result.soraVideos || { published: [], generating: [], unpublished: [] };
      unpublishedVideos = videos.unpublished || [];
    }
    
    // 等待 5 秒再发布下一个
    if (unpublishedVideos.length > 0) {
      addPublishLog('⏳ 等待 5 秒...', 'info');
      await sleep(5000);
    }
  }
  
  addPublishLog('✅ 所有视频发布完成', 'success');
  isPublishing = false;
}

function stopAutoPublish() {
  addPublishLog('⏹️ 停止自动发布', 'warning');
  isPublishing = false;
  publishQueue = [];
}

async function publishVideo(video) {
  return new Promise(async (resolve, reject) => {
    try {
      addPublishLog(`📖 打开视频页面: ${video.url}`, 'info');
      
      // 创建新标签页
      const tab = await chrome.tabs.create({
        url: video.url,
        active: false
      });
      
      addPublishLog(`✅ 标签页已创建: ${tab.id}`, 'success');
      
      // 等待页面加载
      await waitForTabLoad(tab.id);
      addPublishLog('✅ 页面加载完成', 'success');
      
      // 等待页面渲染
      await sleep(3000);
      
      // 注入发布脚本
      addPublishLog('📤 注入发布脚本...', 'info');
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: autoPublishScript
        });
        addPublishLog('✅ 发布脚本已注入', 'success');
      } catch (error) {
        addPublishLog(`⚠️ 注入发布脚本失败: ${error.message}`, 'error');
        throw error;
      }
      
      // 等待发布完成（增加到 45 秒）
      addPublishLog('⏳ 等待发布完成（45秒）...', 'info');
      await sleep(45000);
      
      // 关闭标签页
      addPublishLog(`🗑️ 关闭标签页: ${tab.id}`, 'info');
      await chrome.tabs.remove(tab.id);
      
      addPublishLog(`✅ 视频 ${video.id} 发布流程完成`, 'success');
      resolve();
      
    } catch (error) {
      addPublishLog(`❌ 发布视频 ${video.id} 失败: ${error.message}`, 'error');
      reject(error);
    }
  });
}

// 发布视频并在完成后刷新数据
async function publishVideoWithRefresh(video) {
  return new Promise(async (resolve, reject) => {
    try {
      addPublishLog(`📖 打开视频页面: ${video.url}`, 'info');
      
      // 创建新标签页
      const tab = await chrome.tabs.create({
        url: video.url,
        active: false
      });
      
      addPublishLog(`✅ 标签页已创建: ${tab.id}`, 'success');
      
      // 等待页面加载
      await waitForTabLoad(tab.id);
      addPublishLog('✅ 页面加载完成', 'success');
      
      // 等待页面渲染
      await sleep(3000);
      
      // 注入发布脚本
      addPublishLog('📤 注入发布脚本...', 'info');
      try {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: autoPublishScript
        });
        addPublishLog('✅ 发布脚本已注入', 'success');
      } catch (error) {
        addPublishLog(`⚠️ 注入发布脚本失败: ${error.message}`, 'error');
        throw error;
      }
      
      // 等待发布完成（增加到 45 秒）
      addPublishLog('⏳ 等待发布完成（45秒）...', 'info');
      await sleep(45000);
      
      // 关闭标签页
      addPublishLog(`🗑️ 关闭标签页: ${tab.id}`, 'info');
      await chrome.tabs.remove(tab.id);
      
      addPublishLog(`✅ 视频 ${video.id} 发布流程完成`, 'success');
      resolve();
      
    } catch (error) {
      addPublishLog(`❌ 发布视频 ${video.id} 失败: ${error.message}`, 'error');
      reject(error);
    }
  });
}

// 在视频页面执行的发布脚本
function autoPublishScript() {
  console.log('=== 自动发布脚本启动 ===');
  
  // 等待页面加载
  setTimeout(() => {
    try {
      // 步骤1: 先检查是否已经在编辑状态（有 textarea）
      let textarea = document.querySelector('textarea[placeholder="Add caption..."]');
      
      if (textarea) {
        console.log('✅ 已经在编辑状态');
        clearAndSave();
      } else {
        // 需要先点击编辑按钮
        console.log('🔍 查找编辑按钮...');
        
        const editButton = Array.from(document.querySelectorAll('button')).find(btn => {
          const svg = btn.querySelector('svg');
          if (!svg) return false;
          
          // 查找铅笔图标
          const path = svg.querySelector('path');
          return path && path.getAttribute('d')?.includes('M18.292 5.707');
        });
        
        if (!editButton) {
          console.log('❌ 未找到编辑按钮');
          return;
        }
        
        console.log('✅ 找到编辑按钮，点击...');
        editButton.click();
        
        // 等待编辑界面出现
        setTimeout(() => {
          clearAndSave();
        }, 1500);
      }
      
    } catch (error) {
      console.error('❌ 发布脚本执行失败:', error);
    }
  }, 2000);
  
  // 清空并保存的函数
  function clearAndSave() {
    console.log('🔍 查找 textarea...');
    
    const textarea = document.querySelector('textarea[placeholder="Add caption..."]');
    
    if (!textarea) {
      console.log('❌ 未找到 textarea');
      return;
    }
    
    console.log('✅ 找到 textarea');
    const originalPrompt = textarea.value;
    console.log('原始提示词:', originalPrompt);
    
    // 获取视频URL（当前页面URL）
    const videoUrl = window.location.href;
    console.log('视频URL:', videoUrl);
    
    // 发送提示词和URL到后端进行匹配
    if (originalPrompt && originalPrompt.trim().length > 0) {
      console.log('📤 发送提示词到后端进行任务匹配...');
      
      chrome.storage.local.get(['backendUrl'], (result) => {
        const backendUrl = result.backendUrl || 'http://localhost:8000';
        
        fetch(`${backendUrl}/v1/tasks/match-by-prompt`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            prompt: originalPrompt.trim(),
            video_url: videoUrl
          })
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            console.log('✅ 任务匹配成功:', data.message);
            console.log('   任务ID:', data.task_id);
          } else {
            console.log('⚠️ 未找到匹配的任务:', data.message);
          }
        })
        .catch(error => {
          console.error('❌ 发送匹配请求失败:', error);
        });
      });
    }
    
    // 聚焦并清空
    textarea.focus();
    textarea.value = '';
    
    // 触发所有必要的事件
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
    textarea.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
    textarea.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
    
    console.log('✅ 提示词已清空');
    
    // 步骤2: 查找并点击保存按钮（✓对勾图标）
    setTimeout(() => {
      console.log('🔍 查找保存按钮...');
      
      // 查找包含对勾 SVG 的按钮
      const saveButton = Array.from(document.querySelectorAll('button')).find(btn => {
        const svg = btn.querySelector('svg');
        if (!svg) return false;
        
        // 检查 SVG 的 viewBox 和 path
        const viewBox = svg.getAttribute('viewBox');
        const path = svg.querySelector('path');
        
        return viewBox === '0 0 18 19' && 
               path && 
               path.getAttribute('d')?.includes('M13.548 4.755');
      });
      
      if (!saveButton) {
        console.log('❌ 未找到保存按钮');
        return;
      }
      
      console.log('✅ 找到保存按钮');
      
      // 检查按钮是否禁用
      const isDisabled = saveButton.getAttribute('data-disabled') === 'true';
      console.log('按钮状态:', isDisabled ? '禁用' : '启用');
      
      if (isDisabled) {
        console.log('⚠️ 保存按钮被禁用，尝试启用...');
        saveButton.setAttribute('data-disabled', 'false');
        saveButton.removeAttribute('disabled');
      }
      
      console.log('🚀 点击保存按钮...');
      saveButton.click();
      
      // 步骤3: 等待保存完成，然后点击 Post 按钮
      setTimeout(() => {
        console.log('🔍 查找 Post 按钮...');
        
        const postButton = Array.from(document.querySelectorAll('button')).find(btn => 
          btn.textContent.trim() === 'Post' && 
          btn.classList.contains('bg-token-bg-inverse')
        );
        
        if (!postButton) {
          console.log('❌ 未找到 Post 按钮');
          return;
        }
        
        console.log('✅ 找到 Post 按钮');
        
        // 检查按钮是否禁用
        const isPostDisabled = postButton.getAttribute('data-disabled') === 'true';
        console.log('Post 按钮状态:', isPostDisabled ? '禁用' : '启用');
        
        if (isPostDisabled) {
          console.log('⚠️ Post 按钮被禁用，尝试启用...');
          postButton.setAttribute('data-disabled', 'false');
          postButton.removeAttribute('disabled');
        }
        
        console.log('🚀 点击 Post 按钮...');
        postButton.click();
        
        setTimeout(() => {
          console.log('✅ 发布完成！');
        }, 1000);
        
      }, 2000);
      
    }, 1000);
  }
}
