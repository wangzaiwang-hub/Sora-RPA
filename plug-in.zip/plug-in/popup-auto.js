// Popup 控制脚本
console.log('Popup 加载');

// 加载数据
function loadData() {
  chrome.storage.local.get(['soraVideos', 'lastUpdate'], (result) => {
    if (result.soraVideos) {
      const videos = result.soraVideos;
      const total = videos.published.length + videos.generating.length + videos.unpublished.length;
      
      document.getElementById('total').textContent = total;
      document.getElementById('published').textContent = videos.published.length;
      document.getElementById('generating').textContent = videos.generating.length;
      document.getElementById('unpublished').textContent = videos.unpublished.length;
      
      if (result.lastUpdate) {
        const date = new Date(result.lastUpdate);
        document.getElementById('lastUpdate').textContent = 
          `最后更新: ${date.toLocaleString('zh-CN')}`;
      }
      
      updateStatus('数据已加载', 'success');
    } else {
      updateStatus('暂无数据，请点击"立即收集数据"', 'info');
    }
  });
}

// 更新状态
function updateStatus(message, type = 'info') {
  const statusEl = document.getElementById('status');
  statusEl.textContent = message;
  statusEl.className = `status ${type}`;
}

// 显示/隐藏加载动画
function showLoading(show) {
  const loadingEl = document.getElementById('loading');
  const buttonsEl = document.querySelector('.buttons');
  
  if (show) {
    loadingEl.classList.add('show');
    buttonsEl.style.display = 'none';
  } else {
    loadingEl.classList.remove('show');
    buttonsEl.style.display = 'flex';
  }
}

// 立即收集数据
document.getElementById('collectNow').addEventListener('click', async () => {
  updateStatus('正在收集数据...', 'info');
  showLoading(true);
  
  try {
    // 发送消息到 background
    const response = await chrome.runtime.sendMessage({ 
      type: 'START_AUTO_COLLECT' 
    });
    
    // 等待收集完成（15秒）
    setTimeout(() => {
      showLoading(false);
      loadData();
      updateStatus('收集完成！', 'success');
    }, 15000);
    
  } catch (error) {
    showLoading(false);
    updateStatus('收集失败: ' + error.message, 'info');
  }
});

// 发布未发布视频
document.getElementById('publishUnpublished').addEventListener('click', async () => {
  updateStatus('正在发布未发布视频...', 'info');
  
  try {
    await chrome.runtime.sendMessage({ type: 'START_AUTO_PUBLISH' });
    updateStatus('✅ 自动发布已启动', 'success');
  } catch (error) {
    updateStatus('发布失败: ' + error.message, 'info');
  }
});

// 停止发布
document.getElementById('stopPublish').addEventListener('click', async () => {
  try {
    await chrome.runtime.sendMessage({ type: 'STOP_AUTO_PUBLISH' });
    updateStatus('⏸️ 自动发布已停止', 'info');
  } catch (error) {
    updateStatus('停止失败: ' + error.message, 'info');
  }
});

// 查看发布日志
document.getElementById('viewLogs').addEventListener('click', async () => {
  const logsContainer = document.getElementById('logsContainer');
  const logsList = document.getElementById('logsList');
  
  try {
    const response = await chrome.runtime.sendMessage({ type: 'GET_PUBLISH_LOGS' });
    const logs = response.logs || [];
    
    if (logs.length === 0) {
      logsList.innerHTML = '<div style="color: #999;">暂无日志</div>';
    } else {
      logsList.innerHTML = logs.map(log => {
        const color = log.type === 'error' ? '#F56C6C' : 
                     log.type === 'success' ? '#67C23A' : 
                     log.type === 'warning' ? '#E6A23C' : '#606266';
        return `<div style="margin: 5px 0; color: ${color};">[${log.time}] ${log.message}</div>`;
      }).join('');
    }
    
    logsContainer.style.display = 'block';
  } catch (error) {
    updateStatus('获取日志失败: ' + error.message, 'info');
  }
});

// 关闭日志
document.getElementById('closeLogs').addEventListener('click', () => {
  document.getElementById('logsContainer').style.display = 'none';
});

// 打开管理面板
document.getElementById('openDashboard').addEventListener('click', () => {
  chrome.tabs.create({ url: 'http://localhost:3000/video-stats' });
});

// 初始加载
loadData();

// 每3秒刷新一次数据
setInterval(loadData, 3000);
