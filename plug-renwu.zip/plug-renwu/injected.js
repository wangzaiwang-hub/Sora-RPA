// 注入到页面上下文的拦截器脚本
// 此脚本运行在页面的 JavaScript 上下文中，可以拦截页面的 fetch/XHR 请求

(function() {
  console.log('📡 页面拦截器已注入');
  
  // 保存原始函数
  const originalFetch = window.fetch;
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;
  
  // 🔑 保存捕获到的 Authorization token
  let authToken = null;
  
  // 拦截 Fetch
  window.fetch = async function(...args) {
    const url = typeof args[0] === 'string' ? args[0] : args[0]?.url || 'unknown';
    console.log('📡 Fetch 请求:', url);
    
    // 🔑 捕获 Authorization header
    const options = args[1] || {};
    if (options.headers) {
      const headers = options.headers;
      
      // 检查是否有 Authorization header
      if (headers instanceof Headers) {
        const auth = headers.get('Authorization');
        if (auth && auth.startsWith('Bearer ')) {
          authToken = auth;
          console.log('🔑 捕获到 Authorization token');
        }
      } else if (typeof headers === 'object') {
        const auth = headers['Authorization'] || headers['authorization'];
        if (auth && auth.startsWith('Bearer ')) {
          authToken = auth;
          console.log('🔑 捕获到 Authorization token');
        }
      }
    }
    
    const response = await originalFetch.apply(this, args);
    
    // 克隆响应以便读取
    const clonedResponse = response.clone();
    
    // 检查是否需要捕获
    const shouldCapture = /\/backend\/(project_y|nf)\//.test(url);
    
    if (shouldCapture) {
      try {
        const data = await clonedResponse.json();
        console.log('📦 捕获到响应:', url);
        
        // 通过自定义事件发送到 content script
        window.dispatchEvent(new CustomEvent('soraApiCaptured', {
          detail: { url, data }
        }));
      } catch (error) {
        // 忽略非 JSON 响应
      }
    }
    
    return response;
  };
  
  // 拦截 XMLHttpRequest
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._captureUrl = url;
    this._captureMethod = method;
    console.log('📡 XHR 请求:', method, url);
    return originalOpen.apply(this, [method, url, ...rest]);
  };
  
  const originalSetRequestHeader = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(header, value) {
    // 🔑 捕获 Authorization header
    if (header.toLowerCase() === 'authorization' && value.startsWith('Bearer ')) {
      authToken = value;
      console.log('🔑 捕获到 Authorization token (XHR)');
    }
    return originalSetRequestHeader.apply(this, arguments);
  };
  
  XMLHttpRequest.prototype.send = function(...args) {
    const xhr = this;
    
    this.addEventListener('load', function() {
      const shouldCapture = /\/backend\/(project_y|nf)\//.test(xhr._captureUrl);
      
      if (shouldCapture) {
        try {
          const data = JSON.parse(xhr.responseText);
          console.log('📦 捕获到 XHR 响应:', xhr._captureUrl);
          
          // 通过自定义事件发送到 content script
          window.dispatchEvent(new CustomEvent('soraApiCaptured', {
            detail: { url: xhr._captureUrl, data }
          }));
        } catch (error) {
          // 忽略非 JSON 响应
        }
      }
    });
    
    return originalSend.apply(this, args);
  };
  
  console.log('✅ 页面拦截器设置完成');
  
  // ==================== 草稿验证功能 ====================
  
  /**
   * 验证草稿是否已发布（在页面上下文中，有 cookies）
   */
  async function verifyDraftPublished(generationId) {
    try {
      console.log(`  🔍 [injected.js] 验证草稿 ${generationId} 是否已发布...`);
      
      let draftsData = null;
      
      // 方法1: 检查草稿列表中是否还存在
      const draftsResponse = await originalFetch('https://sora.chatgpt.com/backend/project_y/profile/drafts?limit=50', {
        credentials: 'include',
        headers: authToken ? { 'Authorization': authToken } : {}
      });
      
      if (draftsResponse.ok) {
        draftsData = await draftsResponse.json();
        const stillInDrafts = draftsData.items?.some(item => 
          item.generation_id === generationId || item.id === generationId
        );
        
        if (stillInDrafts) {
          console.log(`  ❌ 草稿仍在 drafts 列表中，未发布`);
          return false;
        }
        
        console.log(`  ✅ 草稿已从 drafts 列表中消失`);
      }
      
      // 方法2: 检查已发布列表中是否存在
      const feedResponse = await originalFetch('https://sora.chatgpt.com/backend/project_y/profile_feed/me?limit=50&cut=nf2', {
        credentials: 'include',
        headers: authToken ? { 'Authorization': authToken } : {}
      });
      
      if (feedResponse.ok) {
        const feedData = await feedResponse.json();
        const inFeed = feedData.items?.some(item => 
          item.generation_id === generationId
        );
        
        if (inFeed) {
          console.log(`  ✅ 草稿已出现在 profile_feed 中，已发布！`);
          return true;
        }
        
        console.log(`  ⚠️ 草稿未在 profile_feed 中找到`);
      }
      
      // 如果不在 drafts 中，认为已发布
      if (draftsData && draftsResponse.ok) {
        const notInDrafts = !draftsData.items?.some(item => 
          item.generation_id === generationId || item.id === generationId
        );
        return notInDrafts;
      }
      
      return false;
      
    } catch (error) {
      console.error(`  ❌ [injected.js] 验证失败:`, error);
      return false;
    }
  }
  
  // 监听来自 content script 的验证请求
  window.addEventListener('verifyDraftRequest', async (event) => {
    const { generationId, requestId } = event.detail;
    console.log(`\n🔍 [injected.js] 收到验证请求: ${generationId}`);
    
    const isPublished = await verifyDraftPublished(generationId);
    
    // 返回验证结果
    window.dispatchEvent(new CustomEvent('verifyDraftResponse', {
      detail: {
        requestId,
        generationId,
        isPublished
      }
    }));
  });
  
  // ==================== 自动发布功能 ====================
  
  // 监听来自 content script 的发布请求
  window.addEventListener('autoPublishDraft', async (event) => {
    const draft = event.detail;
    console.log(`\n🚀 [injected.js] 收到自动发布请求: ${draft.id}`);
    
    // 🔑 检查是否有 token
    if (!authToken) {
      console.error(`  ❌ 没有捕获到 Authorization token，无法发布`);
      console.log(`  💡 提示: 请先在页面上进行一些操作（如刷新页面），让系统捕获 token`);
      
      window.dispatchEvent(new CustomEvent('autoPublishResult', {
        detail: {
          success: false,
          draft_id: draft.id,
          task_id: draft.task_id,
          error: '没有捕获到 Authorization token，请刷新页面后重试'
        }
      }));
      return;
    }
    
    try {
      const generation_id = draft.generation_id || draft.id;
      
      // 调用 Sora 发布 API（使用原始 fetch，有 cookies 和 token）
      const publishPayload = {
        generation_id: generation_id,
        text: draft.prompt || draft.title || '',
        post_locations: ['public'],
        share_setting: 'public'
      };
      
      console.log(`  📤 发布参数:`, publishPayload);
      console.log(`  🔑 使用 Authorization token`);
      
      const publishResponse = await originalFetch('https://sora.chatgpt.com/backend/project_y/post', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': authToken  // 🔑 添加 Authorization header
        },
        credentials: 'include',
        body: JSON.stringify(publishPayload)
      });
      
      if (!publishResponse.ok) {
        const errorText = await publishResponse.text();
        let errorObj;
        let errorMessage = errorText;
        
        try {
          errorObj = JSON.parse(errorText);
          errorMessage = errorObj.error?.message || errorObj.message || errorText;
        } catch {
          errorObj = { error: { message: errorText } };
        }
        
        console.error(`  ❌ 发布失败: HTTP ${publishResponse.status}`);
        console.error(`  错误信息:`, errorObj);
        
        // 🆕 特殊处理幂等性错误（400）
        if (publishResponse.status === 400 && errorMessage.includes('Idempotency check failed')) {
          console.log(`  ℹ️ 幂等性检查失败，该草稿可能已被发布`);
          
          // 通知 content script 标记为已发布
          window.dispatchEvent(new CustomEvent('autoPublishResult', {
            detail: {
              success: false,
              draft_id: draft.id,
              task_id: draft.task_id,
              error: `幂等性检查失败: ${errorMessage}`,
              isIdempotencyError: true  // 🆕 标记为幂等性错误
            }
          }));
          return;
        }
        
        // 🆕 特殊处理速率限制错误（429）
        if (publishResponse.status === 429) {
          console.error(`  ⚠️ 触发速率限制，请稍后重试`);
          
          window.dispatchEvent(new CustomEvent('autoPublishResult', {
            detail: {
              success: false,
              draft_id: draft.id,
              task_id: draft.task_id,
              error: `速率限制: ${errorMessage}`,
              isRateLimitError: true  // 🆕 标记为速率限制错误
            }
          }));
          return;
        }
        
        // 通知 content script 发布失败
        window.dispatchEvent(new CustomEvent('autoPublishResult', {
          detail: {
            success: false,
            draft_id: draft.id,
            task_id: draft.task_id,
            error: `HTTP ${publishResponse.status}: ${errorMessage}`
          }
        }));
        return;
      }
      
      const publishResult = await publishResponse.json();
      console.log(`  ✅ 发布成功！`);
      console.log(`  Post ID: ${publishResult.post.id}`);
      console.log(`  链接: ${publishResult.post.permalink}`);
      
      // 通知 content script 发布成功
      window.dispatchEvent(new CustomEvent('autoPublishResult', {
        detail: {
          success: true,
          draft_id: draft.id,
          task_id: draft.task_id,
          post_id: publishResult.post.id,
          permalink: publishResult.post.permalink,
          posted_at: publishResult.post.posted_at
        }
      }));
      
    } catch (error) {
      console.error(`  ❌ 自动发布失败:`, error);
      
      // 通知 content script 发布失败
      window.dispatchEvent(new CustomEvent('autoPublishResult', {
        detail: {
          success: false,
          draft_id: draft.id,
          task_id: draft.task_id,
          error: error.message
        }
      }));
    }
  });
  
  console.log('✅ 自动发布功能已设置');
})();
