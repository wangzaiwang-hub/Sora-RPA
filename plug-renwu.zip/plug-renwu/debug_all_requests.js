// 调试脚本 - 捕获所有类型的网络请求
// 在控制台运行此脚本来查看页面发送的所有请求

(function() {
  console.log('🔍 开始监听所有网络请求...');
  
  const requests = [];
  
  // 1. 拦截 Fetch
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = typeof args[0] === 'string' ? args[0] : args[0].url;
    console.log('🌐 Fetch:', url);
    requests.push({ type: 'fetch', url, time: new Date() });
    return originalFetch.apply(this, args);
  };
  
  // 2. 拦截 XMLHttpRequest
  const originalOpen = XMLHttpRequest.prototype.open;
  const originalSend = XMLHttpRequest.prototype.send;
  
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._debugUrl = url;
    this._debugMethod = method;
    console.log('🌐 XHR:', method, url);
    requests.push({ type: 'xhr', method, url, time: new Date() });
    return originalOpen.apply(this, [method, url, ...rest]);
  };
  
  // 3. 监听 Performance API
  if (window.PerformanceObserver) {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'resource' && 
            (entry.initiatorType === 'fetch' || entry.initiatorType === 'xmlhttprequest')) {
          console.log('🌐 Performance:', entry.initiatorType, entry.name);
        }
      }
    });
    observer.observe({ entryTypes: ['resource'] });
  }
  
  // 4. 提供查询函数
  window.debugRequests = {
    all: () => {
      console.table(requests);
      return requests;
    },
    
    filter: (keyword) => {
      const filtered = requests.filter(r => r.url.includes(keyword));
      console.table(filtered);
      return filtered;
    },
    
    findMe: () => {
      return requests.filter(r => r.url.includes('/me'));
    },
    
    findCheck: () => {
      return requests.filter(r => r.url.includes('check'));
    },
    
    clear: () => {
      requests.length = 0;
      console.log('✅ 请求记录已清空');
    }
  };
  
  console.log('✅ 监听器已设置');
  console.log('💡 使用方法:');
  console.log('  debugRequests.all()      - 查看所有请求');
  console.log('  debugRequests.filter("me") - 搜索包含 "me" 的请求');
  console.log('  debugRequests.findMe()   - 查找用户信息请求');
  console.log('  debugRequests.findCheck() - 查找配额请求');
  console.log('  debugRequests.clear()    - 清空记录');
  console.log('\n🔄 现在刷新页面 (Ctrl+R) 来捕获请求');
})();
