// Sora 视频抓包调试脚本
// 在浏览器控制台中运行此脚本来查看所有网络请求

console.log('%c🔍 Sora 调试模式已启动', 'color: #667eea; font-size: 16px; font-weight: bold;');

// 存储所有请求
window.soraDebugRequests = [];

// 拦截 Fetch
const originalFetch = window.fetch;
window.fetch = async function(...args) {
  const url = args[0];
  const startTime = Date.now();
  
  console.log('%c📡 Fetch 请求:', 'color: #3b82f6;', url);
  
  try {
    const response = await originalFetch.apply(this, args);
    const clonedResponse = response.clone();
    
    try {
      const data = await clonedResponse.json();
      const duration = Date.now() - startTime;
      
      const requestInfo = {
        type: 'fetch',
        url: url,
        method: args[1]?.method || 'GET',
        status: response.status,
        duration: duration,
        data: data,
        timestamp: new Date().toISOString()
      };
      
      window.soraDebugRequests.push(requestInfo);
      
      console.log('%c✅ Fetch 响应:', 'color: #10b981;', {
        url: url,
        status: response.status,
        duration: `${duration}ms`,
        dataKeys: Object.keys(data)
      });
      
      // 检查是否包含视频数据
      if (data.post && data.post.attachments) {
        console.log('%c🎬 发现视频数据!', 'color: #f59e0b; font-weight: bold;', {
          postId: data.post.id,
          text: data.post.text,
          attachments: data.post.attachments.length
        });
      }
      
      if (data.items && Array.isArray(data.items)) {
        const videoItems = data.items.filter(item => 
          item.post && item.post.attachments && item.post.attachments.length > 0
        );
        if (videoItems.length > 0) {
          console.log(`%c🎬 发现 ${videoItems.length} 个视频数据!`, 'color: #f59e0b; font-weight: bold;');
        }
      }
      
    } catch (e) {
      // 非 JSON 响应
    }
    
    return response;
  } catch (error) {
    console.error('%c❌ Fetch 错误:', 'color: #ef4444;', url, error);
    throw error;
  }
};

// 拦截 XMLHttpRequest
const originalOpen = XMLHttpRequest.prototype.open;
const originalSend = XMLHttpRequest.prototype.send;

XMLHttpRequest.prototype.open = function(method, url, ...rest) {
  this._debugUrl = url;
  this._debugMethod = method;
  this._debugStartTime = Date.now();
  
  console.log('%c📡 XHR 请求:', 'color: #3b82f6;', method, url);
  
  return originalOpen.apply(this, [method, url, ...rest]);
};

XMLHttpRequest.prototype.send = function(...args) {
  this.addEventListener('load', function() {
    const duration = Date.now() - this._debugStartTime;
    
    try {
      const data = JSON.parse(this.responseText);
      
      const requestInfo = {
        type: 'xhr',
        url: this._debugUrl,
        method: this._debugMethod,
        status: this.status,
        duration: duration,
        data: data,
        timestamp: new Date().toISOString()
      };
      
      window.soraDebugRequests.push(requestInfo);
      
      console.log('%c✅ XHR 响应:', 'color: #10b981;', {
        url: this._debugUrl,
        status: this.status,
        duration: `${duration}ms`,
        dataKeys: Object.keys(data)
      });
      
      // 检查是否包含视频数据
      if (data.post && data.post.attachments) {
        console.log('%c🎬 发现视频数据!', 'color: #f59e0b; font-weight: bold;', {
          postId: data.post.id,
          text: data.post.text,
          attachments: data.post.attachments.length
        });
      }
      
    } catch (e) {
      // 非 JSON 响应
    }
  });
  
  return originalSend.apply(this, args);
};

// 辅助函数
window.soraDebug = {
  // 查看所有请求
  showAll: () => {
    console.table(window.soraDebugRequests.map(r => ({
      type: r.type,
      method: r.method,
      url: r.url.substring(0, 80),
      status: r.status,
      duration: `${r.duration}ms`,
      time: r.timestamp
    })));
  },
  
  // 查看包含视频的请求
  showVideos: () => {
    const videoRequests = window.soraDebugRequests.filter(r => 
      (r.data.post && r.data.post.attachments) ||
      (r.data.items && r.data.items.some(item => item.post && item.post.attachments))
    );
    
    console.log(`%c找到 ${videoRequests.length} 个包含视频的请求`, 'color: #667eea; font-size: 14px; font-weight: bold;');
    
    videoRequests.forEach((req, index) => {
      console.group(`%c视频请求 #${index + 1}`, 'color: #667eea;');
      console.log('URL:', req.url);
      console.log('时间:', req.timestamp);
      console.log('数据:', req.data);
      console.groupEnd();
    });
    
    return videoRequests;
  },
  
  // 搜索 URL
  searchUrl: (keyword) => {
    const results = window.soraDebugRequests.filter(r => 
      r.url.toLowerCase().includes(keyword.toLowerCase())
    );
    console.log(`%c找到 ${results.length} 个匹配的请求`, 'color: #667eea;');
    console.table(results.map(r => ({
      type: r.type,
      url: r.url,
      status: r.status
    })));
    return results;
  },
  
  // 清除记录
  clear: () => {
    window.soraDebugRequests = [];
    console.log('%c✅ 已清除所有记录', 'color: #10b981;');
  },
  
  // 导出数据
  export: () => {
    const dataStr = JSON.stringify(window.soraDebugRequests, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sora-debug-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    console.log('%c✅ 数据已导出', 'color: #10b981;');
  },
  
  // 显示帮助
  help: () => {
    console.log(`
%c🔍 Sora 调试工具使用说明

可用命令:
  soraDebug.showAll()      - 查看所有请求
  soraDebug.showVideos()   - 查看包含视频的请求
  soraDebug.searchUrl(keyword) - 搜索 URL
  soraDebug.clear()        - 清除记录
  soraDebug.export()       - 导出数据
  soraDebug.help()         - 显示帮助

示例:
  soraDebug.showVideos()
  soraDebug.searchUrl('posts')
  soraDebug.export()
    `, 'color: #667eea; font-size: 12px;');
  }
};

// 显示帮助
console.log(`
%c💡 提示: 使用 soraDebug.help() 查看可用命令
`, 'color: #667eea; font-size: 12px;');

// 自动显示视频请求
setTimeout(() => {
  const videoCount = window.soraDebugRequests.filter(r => 
    (r.data.post && r.data.post.attachments) ||
    (r.data.items && r.data.items.some(item => item.post && item.post.attachments))
  ).length;
  
  if (videoCount > 0) {
    console.log(`%c🎬 已捕获 ${videoCount} 个视频请求，使用 soraDebug.showVideos() 查看`, 
      'color: #f59e0b; font-size: 14px; font-weight: bold;');
  }
}, 5000);
