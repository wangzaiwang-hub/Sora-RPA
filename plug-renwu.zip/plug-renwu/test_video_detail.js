// 测试视频详情页数据捕获
// 在 Sora 视频详情页的控制台中运行此脚本

console.log('%c🧪 开始测试视频详情页数据捕获', 'color: #667eea; font-size: 16px; font-weight: bold;');

// 获取当前页面的视频 ID
const currentUrl = window.location.href;
const videoIdMatch = currentUrl.match(/\/p\/(s_[a-f0-9]+)/);
const videoId = videoIdMatch ? videoIdMatch[1] : null;

console.log('📍 当前页面:', currentUrl);
console.log('🎯 视频ID:', videoId);

if (!videoId) {
  console.error('❌ 无法从 URL 中提取视频 ID');
  console.log('💡 请确保在视频详情页运行此脚本');
} else {
  console.log('✅ 视频 ID 提取成功');
  
  // 监听网络请求
  console.log('\n📡 开始监听网络请求...');
  console.log('💡 请刷新页面或等待数据加载\n');
  
  // 存储捕获的数据
  window.testCapturedData = null;
  
  // 拦截 Fetch
  const originalFetch = window.fetch;
  window.fetch = async function(...args) {
    const url = args[0];
    
    // 检查 URL 是否包含视频 ID
    if (url.includes(videoId)) {
      console.log('%c🎯 发现包含视频ID的请求!', 'color: #f59e0b; font-weight: bold;');
      console.log('  URL:', url);
    }
    
    const response = await originalFetch.apply(this, args);
    const clonedResponse = response.clone();
    
    try {
      const data = await clonedResponse.json();
      
      // 检查是否包含视频 ID
      if (url.includes(videoId) || JSON.stringify(data).includes(videoId)) {
        console.log('%c✅ 捕获到包含视频数据的响应!', 'color: #10b981; font-weight: bold;');
        console.log('  URL:', url);
        console.log('  数据结构:', Object.keys(data));
        
        // 检查数据结构
        if (data.post) {
          console.log('%c🎬 发现 post 对象!', 'color: #667eea; font-weight: bold;');
          console.log('  Post ID:', data.post.id);
          console.log('  Text:', data.post.text);
          console.log('  Attachments:', data.post.attachments?.length || 0);
          
          if (data.post.attachments && data.post.attachments.length > 0) {
            const attachment = data.post.attachments[0];
            console.log('%c📹 视频信息:', 'color: #667eea;');
            console.log('  Kind:', attachment.kind);
            console.log('  Generation ID:', attachment.generation_id);
            console.log('  Task ID:', attachment.task_id);
            console.log('  Video URL:', attachment.url);
            console.log('  Downloadable URL:', attachment.downloadable_url);
            console.log('  尺寸:', `${attachment.width}x${attachment.height}`);
            console.log('  帧数:', attachment.n_frames);
          }
        }
        
        if (data.profile) {
          console.log('%c👤 用户信息:', 'color: #667eea;');
          console.log('  User ID:', data.profile.user_id);
          console.log('  Username:', data.profile.username);
          console.log('  Verified:', data.profile.verified);
        }
        
        // 保存数据
        window.testCapturedData = data;
        console.log('\n%c💾 数据已保存到 window.testCapturedData', 'color: #10b981;');
        console.log('💡 可以使用 console.log(window.testCapturedData) 查看完整数据\n');
        
        // 显示完整数据结构
        console.group('%c📦 完整数据结构', 'color: #667eea;');
        console.log(data);
        console.groupEnd();
      }
    } catch (e) {
      // 非 JSON 响应
    }
    
    return response;
  };
  
  console.log('\n%c✅ 监听器已设置', 'color: #10b981;');
  console.log('💡 现在刷新页面 (Ctrl+R) 或等待数据加载');
  console.log('💡 捕获到数据后会自动显示详细信息\n');
}

// 辅助函数
window.testHelpers = {
  // 显示捕获的数据
  showData: () => {
    if (window.testCapturedData) {
      console.log('%c📦 捕获的数据:', 'color: #667eea; font-size: 14px;');
      console.log(window.testCapturedData);
    } else {
      console.log('%c⚠️ 还没有捕获到数据', 'color: #f59e0b;');
      console.log('💡 请刷新页面或等待数据加载');
    }
  },
  
  // 提取视频信息
  extractVideoInfo: () => {
    if (!window.testCapturedData) {
      console.log('%c⚠️ 还没有捕获到数据', 'color: #f59e0b;');
      return null;
    }
    
    const data = window.testCapturedData;
    const post = data.post || {};
    const profile = data.profile || {};
    const attachment = post.attachments?.[0] || {};
    
    const videoInfo = {
      post_id: post.id,
      text: post.text,
      posted_at: post.posted_at,
      permalink: post.permalink,
      like_count: post.like_count,
      view_count: post.view_count,
      user_id: profile.user_id,
      username: profile.username,
      generation_id: attachment.generation_id,
      task_id: attachment.task_id,
      video_url: attachment.url,
      downloadable_url: attachment.downloadable_url,
      width: attachment.width,
      height: attachment.height,
      n_frames: attachment.n_frames,
      prompt: attachment.prompt || post.text
    };
    
    console.log('%c📹 提取的视频信息:', 'color: #667eea; font-size: 14px;');
    console.log(videoInfo);
    
    return videoInfo;
  },
  
  // 发送到后端
  sendToBackend: async () => {
    const videoInfo = window.testHelpers.extractVideoInfo();
    if (!videoInfo) return;
    
    console.log('%c📤 发送到后端...', 'color: #3b82f6;');
    
    try {
      const response = await fetch('http://localhost:8000/api/videos/capture', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(videoInfo)
      });
      
      const result = await response.json();
      
      if (result.success) {
        console.log('%c✅ 发送成功!', 'color: #10b981; font-weight: bold;');
        console.log('  消息:', result.message);
        console.log('  视频ID:', result.video_id);
        if (result.matched_task_id) {
          console.log('  匹配的任务ID:', result.matched_task_id);
        }
      } else {
        console.log('%c❌ 发送失败', 'color: #ef4444;');
        console.log('  错误:', result);
      }
    } catch (error) {
      console.error('%c❌ 发送失败:', 'color: #ef4444;', error);
      console.log('💡 请确保后端服务正在运行: python backend/app.py');
    }
  },
  
  // 显示帮助
  help: () => {
    console.log(`
%c🧪 测试工具使用说明

可用命令:
  testHelpers.showData()        - 显示捕获的数据
  testHelpers.extractVideoInfo() - 提取视频信息
  testHelpers.sendToBackend()   - 发送到后端
  testHelpers.help()            - 显示帮助

示例:
  1. 刷新页面等待数据加载
  2. testHelpers.showData()
  3. testHelpers.extractVideoInfo()
  4. testHelpers.sendToBackend()
    `, 'color: #667eea; font-size: 12px;');
  }
};

console.log('\n%c💡 提示: 使用 testHelpers.help() 查看可用命令', 'color: #667eea;');
